炉石外观收藏采集器 · 使用说明
================================

作用：趁《炉石传说》运行期间，读取你「已拥有」的 卡背 / 幸运币 / 英雄皮肤 / 成就，
      生成 2 个 JSON 文件，上传到网站导入页即可查看你的收藏进度。

【使用前】
1. 电脑系统是 Windows（需要 .NET Framework 4.8，Windows 10/11 一般已自带；
   若双击报错「找不到 .NET Framework」，去微软官网装一个 4.8 即可）。
2. 先打开《炉石传说》，并进入任意界面（主菜单即可）。
   建议同时开着 Firestone / Overwolf（本工具依赖其内存读取库，已随包附带在 lib/ 里）。

【运行】
3. 保持本文件夹结构：HsCosmeticsCollector.exe 与 lib/ 文件夹在同一级，不要拆开。
4. 双击 HsCosmeticsCollector.exe（会弹出一个黑色命令行窗口，不要关）。
5. 等待出现类似下面的字样即成功：
       [CardBack] 方法 GetCollectionCardBacks 返回 280 项
       [Coin] 方法 GetCollectionCoins 返回 49 项
       [heroSkin] 已拥有标准英雄皮肤(HERO_* 且 Count>0): 380
       已写入 2 个文件到: ...
       卡背 280 个 / 幸运币 49 个 / 英雄皮肤 380 个 / 成就完成 4117

【产物】
运行后，本文件夹下会多出 2 个文件：
   cosmetics.json      外观收藏（卡背/幸运币/英雄皮肤已拥有的 ID 列表，合并在一个文件里）
   achievements.json   成就（totalCompleted 官方总完成数 / categories 分类完成度 /
                        items 逐条明细：每个成就的 id / status / statusText / progress / isComplete）
把这两个文件上传到网站的「外观导入」页面即可。

【常见问题】
Q: 报错「找不到 UnitySpy.HearthstoneLib.dll」
A: 确认 lib/ 文件夹与 exe 在同一目录；请勿把 exe 单独移到别处。

Q: 报错「炉石未运行 / 无法附加到进程」
A: 先启动炉石传说并进入游戏，再双击本程序；若仍失败，确认 Firestone 也在运行。

Q: 数字和我游戏里看到的不一致？
A: 本工具读的是「已拥有」集合。游戏收藏界面显示的「总数」可能略多（含默认/未解锁项），
   且本工具不读「总数」接口，只报已拥有数。个别新内容若目录未更新，名称可能暂时缺失。

Q: 杀毒软件误报？
A: 本程序直接读取游戏内存，个别杀软会报警，属正常现象，加入白名单即可。
